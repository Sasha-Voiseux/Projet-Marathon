<?php

namespace Database\Seeders;

use App\Models\Commentaire;
use Faker\Factory as Faker;
use Illuminate\Database\Seeder;

class CommentairesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        $faker = Faker::create();
//        $commentaire = new Commentaire();
//        $commentaire->commentaire = "Vik-Team" . $faker->text(300);
//        $commentaire->date = "Vik-Team" . $faker->dateTime();
//        $commentaire->note = "Vik-Team" . $faker->text(300);
//        $commentaire->jeu_id = 1;
//        $commentaire->user_id = 1;
//
//        $commentaire->save();
    }
}
